package sample.Enums;

public enum SeasonType {
    WINTER,
    SPRING,
    SUMMER,
    FALL
}

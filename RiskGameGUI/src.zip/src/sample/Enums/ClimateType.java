package sample.Enums;

public enum ClimateType {
    COLD,
    WARM,
    HOT
}

package sample.Enums;

public enum StageType {
    BEGIN,
    BUY,
    DRAFT,
    ATTACK,
    FORTIFY,
    END
}

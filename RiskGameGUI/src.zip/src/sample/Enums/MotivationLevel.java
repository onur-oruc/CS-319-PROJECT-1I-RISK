package sample.Enums;

public enum MotivationLevel {
    HIGH,
    NORMAL,
    LOW,
    NONE
}

package enums;

public enum TroopCardType {
    ARTILLERY,
    MERCENARY,
    MARINES,
    INFANTRY
}

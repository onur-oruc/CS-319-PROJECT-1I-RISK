package enums;

public enum SeasonType {
    WINTER,
    SPRING,
    SUMMER,
    FALL
}

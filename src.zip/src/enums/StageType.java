package enums;

public enum StageType {
    BUY,
    DRAFT,
    ATTACK,
    FORTIFY
}

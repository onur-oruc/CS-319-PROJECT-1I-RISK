package enums;

public enum MotivationLevel {
    HIGHMOTIVATED,
    NORMALMOTIVATED,
    LOWMOTIVATED,
    UNMOTIVATED
}

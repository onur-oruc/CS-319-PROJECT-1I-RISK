package enums;

public enum ClimateType {
    COLD,
    WARM,
    HOT
}

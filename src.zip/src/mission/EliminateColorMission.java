package mission;

public class EliminateColorMission {
}

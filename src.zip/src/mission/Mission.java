package mission;

import entities.Player;

public interface Mission {
    boolean isCompleted(Player player);
}

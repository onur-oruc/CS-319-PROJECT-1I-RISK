package sample.Enums;

import java.io.Serializable;

public enum TroopCardType implements Serializable {
    ARTILLERY,
    MERCENARY,
    MARINES,
    INFANTRY
}

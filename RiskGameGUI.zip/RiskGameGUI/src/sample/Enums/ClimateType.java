package sample.Enums;

import java.io.Serializable;

public enum ClimateType implements Serializable {
    COLD,
    WARM,
    HOT
}

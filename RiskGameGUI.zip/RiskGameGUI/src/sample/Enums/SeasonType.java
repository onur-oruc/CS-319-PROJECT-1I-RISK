package sample.Enums;

import java.io.Serializable;

public enum SeasonType  implements Serializable {
    WINTER,
    SPRING,
    SUMMER,
    FALL
}

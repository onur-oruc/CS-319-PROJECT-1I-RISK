package sample.Enums;

import java.io.Serializable;

public enum MotivationLevel  implements Serializable {
    HIGH,
    NORMAL,
    LOW,
    NONE
}

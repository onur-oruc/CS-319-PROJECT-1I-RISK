package sample.Enums;

import java.io.Serializable;

public enum StageType implements Serializable {
    BEGIN,
    BUY,
    DRAFT,
    ATTACK,
    FORTIFY,
    END
}
